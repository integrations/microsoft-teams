<b><h1>TinyURL</h1><br><br></b>

A Python script that uses tinyurl.com API to shorten URL's directly from command line.<br><br>

<b>Usage:</b><br>
./tinyurl \<URL\>


