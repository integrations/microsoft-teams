<b><h1>A 21-bit Custom Softcore FPGA-Based Microprocessor</h1></b><br><br>

This hardware project is a design and implementation of a 21-bit custom processor based on Altera DE1-SOC kit.
<br><br><b>Notes:</b><br>- Please note that this project isn't completed yet, it still needs a lot of work, so use with caution.
<br>- For more information, check <i>"21-bit processor.pdf"</i> file included in this repository.

